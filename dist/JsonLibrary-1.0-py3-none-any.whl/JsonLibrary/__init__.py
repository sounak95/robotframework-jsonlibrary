from .JsonLibrary import JsonLibrary
from .version import VERSION
__version__ = VERSION